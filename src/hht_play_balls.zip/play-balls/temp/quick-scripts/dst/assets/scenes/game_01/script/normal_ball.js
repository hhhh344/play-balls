
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scenes/game_01/script/normal_ball.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6917eJLFVVNnZYRpSEwKO4K', 'normal_ball');
// scenes/game_01/script/normal_ball.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    xSpeed: {
      "default": 0,
      type: cc.Float
    },
    ySpeed: {
      "default": 0,
      type: cc.Float
    },
    maxMoveSpeed: {
      "default": 20,
      type: cc.Float
    },
    minMoveSpeed: {
      "default": 8,
      type: cc.Float
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var manager = cc.director.getCollisionManager();
    manager.enabled = true; //manager.enabledDebugDraw = true;
  },
  start: function start() {},
  ballMove: function ballMove() {
    if (Math.abs(this.node.x) + this.node.width / 2 >= this.node.parent.width / 2) {
      this.xSpeed = -this.xSpeed;
    }

    if (Math.abs(this.node.y) + this.node.height / 2 >= this.node.parent.height / 2) {
      this.ySpeed = -this.ySpeed;
    } // this.xSpeed = this.accel * this.xSpeed;
    // this.ySpeed = this.accel * this.ySpeed;


    this.node.x += this.xSpeed;
    this.node.y += this.ySpeed;
  },
  update: function update(dt) {
    this.ballMove();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NlbmVzXFxnYW1lXzAxXFxzY3JpcHRcXG5vcm1hbF9iYWxsLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwieFNwZWVkIiwidHlwZSIsIkZsb2F0IiwieVNwZWVkIiwibWF4TW92ZVNwZWVkIiwibWluTW92ZVNwZWVkIiwib25Mb2FkIiwibWFuYWdlciIsImRpcmVjdG9yIiwiZ2V0Q29sbGlzaW9uTWFuYWdlciIsImVuYWJsZWQiLCJzdGFydCIsImJhbGxNb3ZlIiwiTWF0aCIsImFicyIsIm5vZGUiLCJ4Iiwid2lkdGgiLCJwYXJlbnQiLCJ5IiwiaGVpZ2h0IiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxNQUFNLEVBQUU7QUFDSixpQkFBUyxDQURMO0FBRUpDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZMLEtBREE7QUFNUkMsSUFBQUEsTUFBTSxFQUFFO0FBQ0osaUJBQVMsQ0FETDtBQUVKRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGTCxLQU5BO0FBV1JFLElBQUFBLFlBQVksRUFBRTtBQUNWLGlCQUFTLEVBREM7QUFFVkgsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkMsS0FYTjtBQWdCUkcsSUFBQUEsWUFBWSxFQUFDO0FBQ1QsaUJBQVMsQ0FEQTtBQUVUSixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGQTtBQWhCTCxHQUhQO0FBeUJMO0FBRUFJLEVBQUFBLE1BM0JLLG9CQTJCSztBQUNOLFFBQUlDLE9BQU8sR0FBR1gsRUFBRSxDQUFDWSxRQUFILENBQVlDLG1CQUFaLEVBQWQ7QUFDQUYsSUFBQUEsT0FBTyxDQUFDRyxPQUFSLEdBQWtCLElBQWxCLENBRk0sQ0FHTjtBQUNILEdBL0JJO0FBaUNMQyxFQUFBQSxLQWpDSyxtQkFpQ0ksQ0FFUixDQW5DSTtBQXFDTEMsRUFBQUEsUUFyQ0ssc0JBcUNPO0FBQ1IsUUFBR0MsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS0MsSUFBTCxDQUFVQyxDQUFuQixJQUF3QixLQUFLRCxJQUFMLENBQVVFLEtBQVYsR0FBZ0IsQ0FBeEMsSUFBNkMsS0FBS0YsSUFBTCxDQUFVRyxNQUFWLENBQWlCRCxLQUFqQixHQUF1QixDQUF2RSxFQUEwRTtBQUN0RSxXQUFLakIsTUFBTCxHQUFjLENBQUMsS0FBS0EsTUFBcEI7QUFDSDs7QUFDRCxRQUFHYSxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLQyxJQUFMLENBQVVJLENBQW5CLElBQXdCLEtBQUtKLElBQUwsQ0FBVUssTUFBVixHQUFpQixDQUF6QyxJQUE4QyxLQUFLTCxJQUFMLENBQVVHLE1BQVYsQ0FBaUJFLE1BQWpCLEdBQXdCLENBQXpFLEVBQTRFO0FBQ3hFLFdBQUtqQixNQUFMLEdBQWMsQ0FBQyxLQUFLQSxNQUFwQjtBQUNILEtBTk8sQ0FRUjtBQUNBOzs7QUFFQSxTQUFLWSxJQUFMLENBQVVDLENBQVYsSUFBZSxLQUFLaEIsTUFBcEI7QUFDQSxTQUFLZSxJQUFMLENBQVVJLENBQVYsSUFBZSxLQUFLaEIsTUFBcEI7QUFDSCxHQWxESTtBQW9ETGtCLEVBQUFBLE1BcERLLGtCQW9ER0MsRUFwREgsRUFvRE87QUFDUixTQUFLVixRQUFMO0FBQ0g7QUF0REksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHhTcGVlZDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiAwLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5GbG9hdFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIHlTcGVlZDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiAwLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5GbG9hdFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIG1heE1vdmVTcGVlZDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiAyMCxcclxuICAgICAgICAgICAgdHlwZTogY2MuRmxvYXRcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBtaW5Nb3ZlU3BlZWQ6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiA4LFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5GbG9hdFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICBsZXQgbWFuYWdlciA9IGNjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKTtcclxuICAgICAgICBtYW5hZ2VyLmVuYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgIC8vbWFuYWdlci5lbmFibGVkRGVidWdEcmF3ID0gdHJ1ZTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgYmFsbE1vdmUgKCkge1xyXG4gICAgICAgIGlmKE1hdGguYWJzKHRoaXMubm9kZS54KSArIHRoaXMubm9kZS53aWR0aC8yID49IHRoaXMubm9kZS5wYXJlbnQud2lkdGgvMikge1xyXG4gICAgICAgICAgICB0aGlzLnhTcGVlZCA9IC10aGlzLnhTcGVlZDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYoTWF0aC5hYnModGhpcy5ub2RlLnkpICsgdGhpcy5ub2RlLmhlaWdodC8yID49IHRoaXMubm9kZS5wYXJlbnQuaGVpZ2h0LzIpIHtcclxuICAgICAgICAgICAgdGhpcy55U3BlZWQgPSAtdGhpcy55U3BlZWQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyB0aGlzLnhTcGVlZCA9IHRoaXMuYWNjZWwgKiB0aGlzLnhTcGVlZDtcclxuICAgICAgICAvLyB0aGlzLnlTcGVlZCA9IHRoaXMuYWNjZWwgKiB0aGlzLnlTcGVlZDtcclxuXHJcbiAgICAgICAgdGhpcy5ub2RlLnggKz0gdGhpcy54U3BlZWQ7XHJcbiAgICAgICAgdGhpcy5ub2RlLnkgKz0gdGhpcy55U3BlZWQ7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmJhbGxNb3ZlKCk7XHJcbiAgICB9LFxyXG59KTtcclxuIl19