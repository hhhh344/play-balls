
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/prefabs/script/heart');
require('./assets/prefabs/script/trap');
require('./assets/scenes/game_01/script/game');
require('./assets/scenes/game_01/script/normal_ball');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scenes/game_01/script/game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6a660GvHldAIp3GYXrt1Fs4', 'game');
// scenes/game_01/script/game.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    player: {
      type: cc.Node,
      "default": null
    },
    border: {
      type: cc.Node,
      "default": null
    },
    rectangle: {
      type: cc.Node,
      "default": null
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var _this = this;

    var player = this.player;
    var playerScript = player.getComponent('normal_ball');
    var maxSpeed = playerScript.maxMoveSpeed;
    var minSpeed = playerScript.minMoveSpeed;
    var border = this.border;
    var rect = this.rectangle;
    var rectHeight = rect.height; //rectangle的高度与原高度之比小于该值，则取消发射小球

    var cancelRatio = 0.2; //鼠标与小球的距离≥maxDistance时，蓄力条满

    var maxDistance = 150; //rectangle的高度与原高度之比

    var ratio = 0; //蓄力条向量

    var vecX = 0,
        vecY = 0,
        vecLength = 0; //设置蓄力条透明，位置在小球上

    border.opacity = 0;
    var _ref = [player.x, player.y];
    border.x = _ref[0];
    border.y = _ref[1];
    this.node.on(cc.Node.EventType.TOUCH_START, function (e) {
      if (playerScript.xSpeed == 0 && playerScript.ySpeed == 0) {
        border.opacity = 255;
        vecX = player.x + _this.node.width / 2 - e.getLocationX();
        vecY = player.y + _this.node.height / 2 - e.getLocationY();
        vecLength = Math.sqrt(Math.pow(vecX, 2) + Math.pow(vecY, 2)); //蓄力条角度控制

        var theta = 360 * Math.atan(vecX / vecY) / (2 * Math.PI);

        if (vecY < 0) {
          theta += 180;
        }

        border.angle = -theta; //蓄力条长度控制

        ratio = vecLength / maxDistance;

        if (ratio <= cancelRatio) {
          rect.height = 0;
        } else if (ratio < 1) {
          rect.height = ratio * rectHeight;
        } else {
          rect.height = rectHeight;
        }
      }
    });
    this.node.on(cc.Node.EventType.TOUCH_MOVE, function (e) {
      if (playerScript.xSpeed == 0 && playerScript.ySpeed == 0) {
        vecX = player.x + _this.node.width / 2 - e.getLocationX();
        vecY = player.y + _this.node.height / 2 - e.getLocationY();
        vecLength = Math.sqrt(Math.pow(vecX, 2) + Math.pow(vecY, 2)); //蓄力条角度控制

        var theta = 360 * Math.atan(vecX / vecY) / (2 * Math.PI);

        if (vecY < 0) {
          theta += 180;
        }

        border.angle = -theta; //蓄力条长度控制

        ratio = vecLength / maxDistance;

        if (ratio <= cancelRatio) {
          rect.height = 0;
        } else if (ratio < 1) {
          rect.height = ratio * rectHeight;
        } else {
          rect.height = rectHeight;
        }
      }
    });
    this.node.on(cc.Node.EventType.TOUCH_END, function (e) {
      if (playerScript.xSpeed == 0 && playerScript.ySpeed == 0) {
        border.opacity = 0;
        var deltaSpeed = maxSpeed - minSpeed;
        var cosTheta = vecX / vecLength;
        var sinTheta = vecY / vecLength;
        var speed = ratio * deltaSpeed + minSpeed;

        if (ratio > cancelRatio) {
          var _ref2 = [cosTheta * speed, sinTheta * speed];
          playerScript.xSpeed = _ref2[0];
          playerScript.ySpeed = _ref2[1];
        }
      }
    });
  },
  start: function start() {},
  update: function update(dt) {// if(this.canLaunch === true) {
    //     const playerScript = this.player.getComponent('normal_ball');
    //     [playerScript.xSpeed, playerScript.ySpeed] = 
    //     [this.cosTheta * this.speed, this.sinTheta * this.speed];
    //     this.canLaunch = false;
    // }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NlbmVzXFxnYW1lXzAxXFxzY3JpcHRcXGdhbWUuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJwbGF5ZXIiLCJ0eXBlIiwiTm9kZSIsImJvcmRlciIsInJlY3RhbmdsZSIsIm9uTG9hZCIsInBsYXllclNjcmlwdCIsImdldENvbXBvbmVudCIsIm1heFNwZWVkIiwibWF4TW92ZVNwZWVkIiwibWluU3BlZWQiLCJtaW5Nb3ZlU3BlZWQiLCJyZWN0IiwicmVjdEhlaWdodCIsImhlaWdodCIsImNhbmNlbFJhdGlvIiwibWF4RGlzdGFuY2UiLCJyYXRpbyIsInZlY1giLCJ2ZWNZIiwidmVjTGVuZ3RoIiwib3BhY2l0eSIsIngiLCJ5Iiwibm9kZSIsIm9uIiwiRXZlbnRUeXBlIiwiVE9VQ0hfU1RBUlQiLCJlIiwieFNwZWVkIiwieVNwZWVkIiwid2lkdGgiLCJnZXRMb2NhdGlvblgiLCJnZXRMb2NhdGlvblkiLCJNYXRoIiwic3FydCIsInRoZXRhIiwiYXRhbiIsIlBJIiwiYW5nbGUiLCJUT1VDSF9NT1ZFIiwiVE9VQ0hfRU5EIiwiZGVsdGFTcGVlZCIsImNvc1RoZXRhIiwic2luVGhldGEiLCJzcGVlZCIsInN0YXJ0IiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBRUxDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxNQUFNLEVBQUU7QUFDSkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLElBREw7QUFFSixpQkFBUztBQUZMLEtBREE7QUFNUkMsSUFBQUEsTUFBTSxFQUFFO0FBQ0pGLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxJQURMO0FBRUosaUJBQVM7QUFGTCxLQU5BO0FBV1JFLElBQUFBLFNBQVMsRUFBRTtBQUNQSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sSUFERjtBQUVQLGlCQUFTO0FBRkY7QUFYSCxHQUZQO0FBbUJMO0FBRUFHLEVBQUFBLE1BckJLLG9CQXFCSztBQUFBOztBQUNOLFFBQU1MLE1BQU0sR0FBRyxLQUFLQSxNQUFwQjtBQUNBLFFBQU1NLFlBQVksR0FBR04sTUFBTSxDQUFDTyxZQUFQLENBQW9CLGFBQXBCLENBQXJCO0FBQ0EsUUFBTUMsUUFBUSxHQUFHRixZQUFZLENBQUNHLFlBQTlCO0FBQ0EsUUFBTUMsUUFBUSxHQUFHSixZQUFZLENBQUNLLFlBQTlCO0FBRUEsUUFBTVIsTUFBTSxHQUFHLEtBQUtBLE1BQXBCO0FBQ0EsUUFBTVMsSUFBSSxHQUFHLEtBQUtSLFNBQWxCO0FBQ0EsUUFBTVMsVUFBVSxHQUFHRCxJQUFJLENBQUNFLE1BQXhCLENBUk0sQ0FVTjs7QUFDQSxRQUFNQyxXQUFXLEdBQUcsR0FBcEIsQ0FYTSxDQWFOOztBQUNBLFFBQU1DLFdBQVcsR0FBRyxHQUFwQixDQWRNLENBZ0JOOztBQUNBLFFBQUlDLEtBQUssR0FBRyxDQUFaLENBakJNLENBbUJOOztBQW5CTSxRQW9CREMsSUFwQkMsR0FvQnlCLENBcEJ6QjtBQUFBLFFBb0JLQyxJQXBCTCxHQW9CNEIsQ0FwQjVCO0FBQUEsUUFvQldDLFNBcEJYLEdBb0IrQixDQXBCL0IsRUFzQk47O0FBQ0FqQixJQUFBQSxNQUFNLENBQUNrQixPQUFQLEdBQWlCLENBQWpCO0FBdkJNLGVBd0JpQixDQUFDckIsTUFBTSxDQUFDc0IsQ0FBUixFQUFXdEIsTUFBTSxDQUFDdUIsQ0FBbEIsQ0F4QmpCO0FBd0JMcEIsSUFBQUEsTUFBTSxDQUFDbUIsQ0F4QkY7QUF3QktuQixJQUFBQSxNQUFNLENBQUNvQixDQXhCWjtBQTBCTixTQUFLQyxJQUFMLENBQVVDLEVBQVYsQ0FBYTdCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRd0IsU0FBUixDQUFrQkMsV0FBL0IsRUFBNEMsVUFBQUMsQ0FBQyxFQUFJO0FBQzdDLFVBQUd0QixZQUFZLENBQUN1QixNQUFiLElBQXVCLENBQXZCLElBQTRCdkIsWUFBWSxDQUFDd0IsTUFBYixJQUF1QixDQUF0RCxFQUF5RDtBQUNyRDNCLFFBQUFBLE1BQU0sQ0FBQ2tCLE9BQVAsR0FBaUIsR0FBakI7QUFFQ0gsUUFBQUEsSUFIb0QsR0FJcERsQixNQUFNLENBQUNzQixDQUFQLEdBQVcsS0FBSSxDQUFDRSxJQUFMLENBQVVPLEtBQVYsR0FBZ0IsQ0FBM0IsR0FBK0JILENBQUMsQ0FBQ0ksWUFBRixFQUpxQjtBQUc5Q2IsUUFBQUEsSUFIOEMsR0FJSG5CLE1BQU0sQ0FBQ3VCLENBQVAsR0FBVyxLQUFJLENBQUNDLElBQUwsQ0FBVVYsTUFBVixHQUFpQixDQUE1QixHQUFnQ2MsQ0FBQyxDQUFDSyxZQUFGLEVBSjdCO0FBS3JEYixRQUFBQSxTQUFTLEdBQUdjLElBQUksQ0FBQ0MsSUFBTCxDQUFVLFNBQUFqQixJQUFJLEVBQUUsQ0FBRixDQUFKLFlBQVVDLElBQVYsRUFBZ0IsQ0FBaEIsQ0FBVixDQUFaLENBTHFELENBT3JEOztBQUNBLFlBQUlpQixLQUFLLEdBQUcsTUFBTUYsSUFBSSxDQUFDRyxJQUFMLENBQVVuQixJQUFJLEdBQUNDLElBQWYsQ0FBTixJQUE0QixJQUFFZSxJQUFJLENBQUNJLEVBQW5DLENBQVo7O0FBQ0EsWUFBR25CLElBQUksR0FBRyxDQUFWLEVBQWE7QUFDVGlCLFVBQUFBLEtBQUssSUFBSSxHQUFUO0FBQ0g7O0FBQ0RqQyxRQUFBQSxNQUFNLENBQUNvQyxLQUFQLEdBQWUsQ0FBQ0gsS0FBaEIsQ0FacUQsQ0FjckQ7O0FBQ0FuQixRQUFBQSxLQUFLLEdBQUdHLFNBQVMsR0FBQ0osV0FBbEI7O0FBQ0EsWUFBR0MsS0FBSyxJQUFJRixXQUFaLEVBQXlCO0FBQ3JCSCxVQUFBQSxJQUFJLENBQUNFLE1BQUwsR0FBYyxDQUFkO0FBQ0gsU0FGRCxNQUdLLElBQUdHLEtBQUssR0FBRyxDQUFYLEVBQWM7QUFDZkwsVUFBQUEsSUFBSSxDQUFDRSxNQUFMLEdBQWNHLEtBQUssR0FBR0osVUFBdEI7QUFDSCxTQUZJLE1BR0E7QUFDREQsVUFBQUEsSUFBSSxDQUFDRSxNQUFMLEdBQWNELFVBQWQ7QUFDSDtBQUNKO0FBQ0osS0EzQkQ7QUE2QkEsU0FBS1csSUFBTCxDQUFVQyxFQUFWLENBQWE3QixFQUFFLENBQUNNLElBQUgsQ0FBUXdCLFNBQVIsQ0FBa0JjLFVBQS9CLEVBQTJDLFVBQUFaLENBQUMsRUFBSTtBQUM1QyxVQUFHdEIsWUFBWSxDQUFDdUIsTUFBYixJQUF1QixDQUF2QixJQUE0QnZCLFlBQVksQ0FBQ3dCLE1BQWIsSUFBdUIsQ0FBdEQsRUFBeUQ7QUFDcERaLFFBQUFBLElBRG9ELEdBRXBEbEIsTUFBTSxDQUFDc0IsQ0FBUCxHQUFXLEtBQUksQ0FBQ0UsSUFBTCxDQUFVTyxLQUFWLEdBQWdCLENBQTNCLEdBQStCSCxDQUFDLENBQUNJLFlBQUYsRUFGcUI7QUFDOUNiLFFBQUFBLElBRDhDLEdBRUhuQixNQUFNLENBQUN1QixDQUFQLEdBQVcsS0FBSSxDQUFDQyxJQUFMLENBQVVWLE1BQVYsR0FBaUIsQ0FBNUIsR0FBZ0NjLENBQUMsQ0FBQ0ssWUFBRixFQUY3QjtBQUdyRGIsUUFBQUEsU0FBUyxHQUFHYyxJQUFJLENBQUNDLElBQUwsQ0FBVSxTQUFBakIsSUFBSSxFQUFFLENBQUYsQ0FBSixZQUFVQyxJQUFWLEVBQWdCLENBQWhCLENBQVYsQ0FBWixDQUhxRCxDQUtyRDs7QUFDQSxZQUFJaUIsS0FBSyxHQUFHLE1BQU1GLElBQUksQ0FBQ0csSUFBTCxDQUFVbkIsSUFBSSxHQUFDQyxJQUFmLENBQU4sSUFBNEIsSUFBRWUsSUFBSSxDQUFDSSxFQUFuQyxDQUFaOztBQUNBLFlBQUduQixJQUFJLEdBQUcsQ0FBVixFQUFhO0FBQ1RpQixVQUFBQSxLQUFLLElBQUksR0FBVDtBQUNIOztBQUNEakMsUUFBQUEsTUFBTSxDQUFDb0MsS0FBUCxHQUFlLENBQUNILEtBQWhCLENBVnFELENBWXJEOztBQUNBbkIsUUFBQUEsS0FBSyxHQUFHRyxTQUFTLEdBQUNKLFdBQWxCOztBQUNBLFlBQUdDLEtBQUssSUFBSUYsV0FBWixFQUF5QjtBQUNyQkgsVUFBQUEsSUFBSSxDQUFDRSxNQUFMLEdBQWMsQ0FBZDtBQUNILFNBRkQsTUFHSyxJQUFHRyxLQUFLLEdBQUcsQ0FBWCxFQUFjO0FBQ2ZMLFVBQUFBLElBQUksQ0FBQ0UsTUFBTCxHQUFjRyxLQUFLLEdBQUdKLFVBQXRCO0FBQ0gsU0FGSSxNQUdBO0FBQ0RELFVBQUFBLElBQUksQ0FBQ0UsTUFBTCxHQUFjRCxVQUFkO0FBQ0g7QUFDSjtBQUNKLEtBekJEO0FBMkJBLFNBQUtXLElBQUwsQ0FBVUMsRUFBVixDQUFhN0IsRUFBRSxDQUFDTSxJQUFILENBQVF3QixTQUFSLENBQWtCZSxTQUEvQixFQUEwQyxVQUFBYixDQUFDLEVBQUk7QUFDM0MsVUFBR3RCLFlBQVksQ0FBQ3VCLE1BQWIsSUFBdUIsQ0FBdkIsSUFBNEJ2QixZQUFZLENBQUN3QixNQUFiLElBQXVCLENBQXRELEVBQXlEO0FBQ3JEM0IsUUFBQUEsTUFBTSxDQUFDa0IsT0FBUCxHQUFpQixDQUFqQjtBQUNBLFlBQU1xQixVQUFVLEdBQUdsQyxRQUFRLEdBQUdFLFFBQTlCO0FBQ0EsWUFBTWlDLFFBQVEsR0FBR3pCLElBQUksR0FBQ0UsU0FBdEI7QUFDQSxZQUFNd0IsUUFBUSxHQUFHekIsSUFBSSxHQUFDQyxTQUF0QjtBQUNBLFlBQU15QixLQUFLLEdBQUc1QixLQUFLLEdBQUd5QixVQUFSLEdBQXFCaEMsUUFBbkM7O0FBQ0EsWUFBR08sS0FBSyxHQUFHRixXQUFYLEVBQXdCO0FBQUEsc0JBRXBCLENBQUM0QixRQUFRLEdBQUdFLEtBQVosRUFBbUJELFFBQVEsR0FBR0MsS0FBOUIsQ0FGb0I7QUFDbkJ2QyxVQUFBQSxZQUFZLENBQUN1QixNQURNO0FBQ0V2QixVQUFBQSxZQUFZLENBQUN3QixNQURmO0FBR3ZCO0FBQ0o7QUFDSixLQVpEO0FBY0gsR0FySEk7QUF1SExnQixFQUFBQSxLQXZISyxtQkF1SEksQ0FFUixDQXpISTtBQTJITEMsRUFBQUEsTUEzSEssa0JBMkhHQyxFQTNISCxFQTJITyxDQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBbElJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBwbGF5ZXI6IHtcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBib3JkZXI6IHtcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICByZWN0YW5nbGU6IHtcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgICAgY29uc3QgcGxheWVyID0gdGhpcy5wbGF5ZXI7XHJcbiAgICAgICAgY29uc3QgcGxheWVyU2NyaXB0ID0gcGxheWVyLmdldENvbXBvbmVudCgnbm9ybWFsX2JhbGwnKTtcclxuICAgICAgICBjb25zdCBtYXhTcGVlZCA9IHBsYXllclNjcmlwdC5tYXhNb3ZlU3BlZWQ7XHJcbiAgICAgICAgY29uc3QgbWluU3BlZWQgPSBwbGF5ZXJTY3JpcHQubWluTW92ZVNwZWVkO1xyXG5cclxuICAgICAgICBjb25zdCBib3JkZXIgPSB0aGlzLmJvcmRlcjtcclxuICAgICAgICBjb25zdCByZWN0ID0gdGhpcy5yZWN0YW5nbGU7XHJcbiAgICAgICAgY29uc3QgcmVjdEhlaWdodCA9IHJlY3QuaGVpZ2h0O1xyXG5cclxuICAgICAgICAvL3JlY3RhbmdsZeeahOmrmOW6puS4juWOn+mrmOW6puS5i+avlOWwj+S6juivpeWAvO+8jOWImeWPlua2iOWPkeWwhOWwj+eQg1xyXG4gICAgICAgIGNvbnN0IGNhbmNlbFJhdGlvID0gMC4yO1xyXG5cclxuICAgICAgICAvL+m8oOagh+S4juWwj+eQg+eahOi3neemu+KJpW1heERpc3RhbmNl5pe277yM6JOE5Yqb5p2h5ruhXHJcbiAgICAgICAgY29uc3QgbWF4RGlzdGFuY2UgPSAxNTA7XHJcblxyXG4gICAgICAgIC8vcmVjdGFuZ2xl55qE6auY5bqm5LiO5Y6f6auY5bqm5LmL5q+UXHJcbiAgICAgICAgbGV0IHJhdGlvID0gMDtcclxuXHJcbiAgICAgICAgLy/ok4TlipvmnaHlkJHph49cclxuICAgICAgICBsZXQgW3ZlY1gsIHZlY1ksIHZlY0xlbmd0aF0gPSBbMCwgMCwgMF07XHJcblxyXG4gICAgICAgIC8v6K6+572u6JOE5Yqb5p2h6YCP5piO77yM5L2N572u5Zyo5bCP55CD5LiKXHJcbiAgICAgICAgYm9yZGVyLm9wYWNpdHkgPSAwO1xyXG4gICAgICAgIFtib3JkZXIueCwgYm9yZGVyLnldID0gW3BsYXllci54LCBwbGF5ZXIueV07XHJcblxyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgZSA9PiB7XHJcbiAgICAgICAgICAgIGlmKHBsYXllclNjcmlwdC54U3BlZWQgPT0gMCAmJiBwbGF5ZXJTY3JpcHQueVNwZWVkID09IDApIHtcclxuICAgICAgICAgICAgICAgIGJvcmRlci5vcGFjaXR5ID0gMjU1O1xyXG5cclxuICAgICAgICAgICAgICAgIFt2ZWNYLCB2ZWNZXSA9IFxyXG4gICAgICAgICAgICAgICAgW3BsYXllci54ICsgdGhpcy5ub2RlLndpZHRoLzIgLSBlLmdldExvY2F0aW9uWCgpLCBwbGF5ZXIueSArIHRoaXMubm9kZS5oZWlnaHQvMiAtIGUuZ2V0TG9jYXRpb25ZKCldO1xyXG4gICAgICAgICAgICAgICAgdmVjTGVuZ3RoID0gTWF0aC5zcXJ0KHZlY1gqKjIgKyB2ZWNZKioyKTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy/ok4TlipvmnaHop5LluqbmjqfliLZcclxuICAgICAgICAgICAgICAgIGxldCB0aGV0YSA9IDM2MCAqIE1hdGguYXRhbih2ZWNYL3ZlY1kpLygyKk1hdGguUEkpO1xyXG4gICAgICAgICAgICAgICAgaWYodmVjWSA8IDApIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGV0YSArPSAxODA7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBib3JkZXIuYW5nbGUgPSAtdGhldGE7XHJcblxyXG4gICAgICAgICAgICAgICAgLy/ok4TlipvmnaHplb/luqbmjqfliLZcclxuICAgICAgICAgICAgICAgIHJhdGlvID0gdmVjTGVuZ3RoL21heERpc3RhbmNlO1xyXG4gICAgICAgICAgICAgICAgaWYocmF0aW8gPD0gY2FuY2VsUmF0aW8pIHtcclxuICAgICAgICAgICAgICAgICAgICByZWN0LmhlaWdodCA9IDA7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmKHJhdGlvIDwgMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJlY3QuaGVpZ2h0ID0gcmF0aW8gKiByZWN0SGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVjdC5oZWlnaHQgPSByZWN0SGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLCBlID0+IHtcclxuICAgICAgICAgICAgaWYocGxheWVyU2NyaXB0LnhTcGVlZCA9PSAwICYmIHBsYXllclNjcmlwdC55U3BlZWQgPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgW3ZlY1gsIHZlY1ldID0gXHJcbiAgICAgICAgICAgICAgICBbcGxheWVyLnggKyB0aGlzLm5vZGUud2lkdGgvMiAtIGUuZ2V0TG9jYXRpb25YKCksIHBsYXllci55ICsgdGhpcy5ub2RlLmhlaWdodC8yIC0gZS5nZXRMb2NhdGlvblkoKV07XHJcbiAgICAgICAgICAgICAgICB2ZWNMZW5ndGggPSBNYXRoLnNxcnQodmVjWCoqMiArIHZlY1kqKjIpO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAvL+iThOWKm+adoeinkuW6puaOp+WItlxyXG4gICAgICAgICAgICAgICAgbGV0IHRoZXRhID0gMzYwICogTWF0aC5hdGFuKHZlY1gvdmVjWSkvKDIqTWF0aC5QSSk7XHJcbiAgICAgICAgICAgICAgICBpZih2ZWNZIDwgMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoZXRhICs9IDE4MDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJvcmRlci5hbmdsZSA9IC10aGV0YTtcclxuXHJcbiAgICAgICAgICAgICAgICAvL+iThOWKm+adoemVv+W6puaOp+WItlxyXG4gICAgICAgICAgICAgICAgcmF0aW8gPSB2ZWNMZW5ndGgvbWF4RGlzdGFuY2U7XHJcbiAgICAgICAgICAgICAgICBpZihyYXRpbyA8PSBjYW5jZWxSYXRpbykge1xyXG4gICAgICAgICAgICAgICAgICAgIHJlY3QuaGVpZ2h0ID0gMDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYocmF0aW8gPCAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVjdC5oZWlnaHQgPSByYXRpbyAqIHJlY3RIZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICByZWN0LmhlaWdodCA9IHJlY3RIZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCwgZSA9PiB7XHJcbiAgICAgICAgICAgIGlmKHBsYXllclNjcmlwdC54U3BlZWQgPT0gMCAmJiBwbGF5ZXJTY3JpcHQueVNwZWVkID09IDApIHtcclxuICAgICAgICAgICAgICAgIGJvcmRlci5vcGFjaXR5ID0gMDtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGRlbHRhU3BlZWQgPSBtYXhTcGVlZCAtIG1pblNwZWVkO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgY29zVGhldGEgPSB2ZWNYL3ZlY0xlbmd0aDtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHNpblRoZXRhID0gdmVjWS92ZWNMZW5ndGg7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBzcGVlZCA9IHJhdGlvICogZGVsdGFTcGVlZCArIG1pblNwZWVkO1xyXG4gICAgICAgICAgICAgICAgaWYocmF0aW8gPiBjYW5jZWxSYXRpbykge1xyXG4gICAgICAgICAgICAgICAgICAgIFtwbGF5ZXJTY3JpcHQueFNwZWVkLCBwbGF5ZXJTY3JpcHQueVNwZWVkXSA9IFxyXG4gICAgICAgICAgICAgICAgICAgIFtjb3NUaGV0YSAqIHNwZWVkLCBzaW5UaGV0YSAqIHNwZWVkXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcblxyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgLy8gaWYodGhpcy5jYW5MYXVuY2ggPT09IHRydWUpIHtcclxuICAgICAgICAvLyAgICAgY29uc3QgcGxheWVyU2NyaXB0ID0gdGhpcy5wbGF5ZXIuZ2V0Q29tcG9uZW50KCdub3JtYWxfYmFsbCcpO1xyXG4gICAgICAgIC8vICAgICBbcGxheWVyU2NyaXB0LnhTcGVlZCwgcGxheWVyU2NyaXB0LnlTcGVlZF0gPSBcclxuICAgICAgICAvLyAgICAgW3RoaXMuY29zVGhldGEgKiB0aGlzLnNwZWVkLCB0aGlzLnNpblRoZXRhICogdGhpcy5zcGVlZF07XHJcbiAgICAgICAgLy8gICAgIHRoaXMuY2FuTGF1bmNoID0gZmFsc2U7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgfSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/prefabs/script/trap.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6341fEmalJPZKYBNwA2z0ZQ', 'trap');
// prefabs/script/trap.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    nextSceneName: {
      type: cc.String,
      "default": 'game_01'
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var manager = cc.director.getCollisionManager();
    manager.enabled = true; // manager.enabledDebugDraw = true;
  },
  start: function start() {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    console.log('fail');
    cc.director.loadScene(this.nextSceneName);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccHJlZmFic1xcc2NyaXB0XFx0cmFwLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwibmV4dFNjZW5lTmFtZSIsInR5cGUiLCJTdHJpbmciLCJvbkxvYWQiLCJtYW5hZ2VyIiwiZGlyZWN0b3IiLCJnZXRDb2xsaXNpb25NYW5hZ2VyIiwiZW5hYmxlZCIsInN0YXJ0Iiwib25Db2xsaXNpb25FbnRlciIsIm90aGVyIiwic2VsZiIsImNvbnNvbGUiLCJsb2ciLCJsb2FkU2NlbmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxhQUFhLEVBQUU7QUFDWEMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLE1BREU7QUFFWCxpQkFBUztBQUZFO0FBRFAsR0FIUDtBQVVMO0FBRUFDLEVBQUFBLE1BWkssb0JBWUs7QUFDTixRQUFJQyxPQUFPLEdBQUdSLEVBQUUsQ0FBQ1MsUUFBSCxDQUFZQyxtQkFBWixFQUFkO0FBQ0FGLElBQUFBLE9BQU8sQ0FBQ0csT0FBUixHQUFrQixJQUFsQixDQUZNLENBR047QUFDSCxHQWhCSTtBQWtCTEMsRUFBQUEsS0FsQkssbUJBa0JJLENBRVIsQ0FwQkk7QUFzQkxDLEVBQUFBLGdCQUFnQixFQUFFLDBCQUFTQyxLQUFULEVBQWdCQyxJQUFoQixFQUFzQjtBQUNwQ0MsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNBakIsSUFBQUEsRUFBRSxDQUFDUyxRQUFILENBQVlTLFNBQVosQ0FBc0IsS0FBS2QsYUFBM0I7QUFDSCxHQXpCSSxDQTJCTDs7QUEzQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIG5leHRTY2VuZU5hbWU6IHtcclxuICAgICAgICAgICAgdHlwZTogY2MuU3RyaW5nLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiAnZ2FtZV8wMScsXHJcbiAgICAgICAgfSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICBsZXQgbWFuYWdlciA9IGNjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKTtcclxuICAgICAgICBtYW5hZ2VyLmVuYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgIC8vIG1hbmFnZXIuZW5hYmxlZERlYnVnRHJhdyA9IHRydWU7XHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIG9uQ29sbGlzaW9uRW50ZXI6IGZ1bmN0aW9uKG90aGVyLCBzZWxmKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2ZhaWwnKTtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUodGhpcy5uZXh0U2NlbmVOYW1lKTtcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/prefabs/script/heart.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e34f9ZPS2BFdYRhX8PQ4I8j', 'heart');
// prefabs/script/heart.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    nextSceneName: {
      type: cc.String,
      "default": 'game_01'
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var manager = cc.director.getCollisionManager();
    manager.enabled = true;
  },
  start: function start() {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    console.log('win');
    cc.director.loadScene(this.nextSceneName);
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccHJlZmFic1xcc2NyaXB0XFxoZWFydC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIm5leHRTY2VuZU5hbWUiLCJ0eXBlIiwiU3RyaW5nIiwib25Mb2FkIiwibWFuYWdlciIsImRpcmVjdG9yIiwiZ2V0Q29sbGlzaW9uTWFuYWdlciIsImVuYWJsZWQiLCJzdGFydCIsIm9uQ29sbGlzaW9uRW50ZXIiLCJvdGhlciIsInNlbGYiLCJjb25zb2xlIiwibG9nIiwibG9hZFNjZW5lIiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxhQUFhLEVBQUU7QUFDWEMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLE1BREU7QUFFWCxpQkFBUztBQUZFO0FBRFAsR0FIUDtBQVVMO0FBRUFDLEVBQUFBLE1BWkssb0JBWUs7QUFDTixRQUFJQyxPQUFPLEdBQUdSLEVBQUUsQ0FBQ1MsUUFBSCxDQUFZQyxtQkFBWixFQUFkO0FBQ0FGLElBQUFBLE9BQU8sQ0FBQ0csT0FBUixHQUFrQixJQUFsQjtBQUNILEdBZkk7QUFpQkxDLEVBQUFBLEtBakJLLG1CQWlCSSxDQUVSLENBbkJJO0FBcUJMQyxFQUFBQSxnQkFBZ0IsRUFBRSwwQkFBU0MsS0FBVCxFQUFnQkMsSUFBaEIsRUFBc0I7QUFDcENDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVo7QUFDQWpCLElBQUFBLEVBQUUsQ0FBQ1MsUUFBSCxDQUFZUyxTQUFaLENBQXNCLEtBQUtkLGFBQTNCO0FBQ0gsR0F4Qkk7QUEwQkxlLEVBQUFBLE1BMUJLLGtCQTBCR0MsRUExQkgsRUEwQk8sQ0FBRTtBQTFCVCxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgbmV4dFNjZW5lTmFtZToge1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5TdHJpbmcsXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6ICdnYW1lXzAxJyxcclxuICAgICAgICB9LFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIGxldCBtYW5hZ2VyID0gY2MuZGlyZWN0b3IuZ2V0Q29sbGlzaW9uTWFuYWdlcigpO1xyXG4gICAgICAgIG1hbmFnZXIuZW5hYmxlZCA9IHRydWU7XHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIG9uQ29sbGlzaW9uRW50ZXI6IGZ1bmN0aW9uKG90aGVyLCBzZWxmKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3dpbicpO1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSh0aGlzLm5leHRTY2VuZU5hbWUpO1xyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scenes/game_01/script/normal_ball.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6917eJLFVVNnZYRpSEwKO4K', 'normal_ball');
// scenes/game_01/script/normal_ball.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    xSpeed: {
      "default": 0,
      type: cc.Float
    },
    ySpeed: {
      "default": 0,
      type: cc.Float
    },
    maxMoveSpeed: {
      "default": 20,
      type: cc.Float
    },
    minMoveSpeed: {
      "default": 8,
      type: cc.Float
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var manager = cc.director.getCollisionManager();
    manager.enabled = true; //manager.enabledDebugDraw = true;
  },
  start: function start() {},
  ballMove: function ballMove() {
    if (Math.abs(this.node.x) + this.node.width / 2 >= this.node.parent.width / 2) {
      this.xSpeed = -this.xSpeed;
    }

    if (Math.abs(this.node.y) + this.node.height / 2 >= this.node.parent.height / 2) {
      this.ySpeed = -this.ySpeed;
    } // this.xSpeed = this.accel * this.xSpeed;
    // this.ySpeed = this.accel * this.ySpeed;


    this.node.x += this.xSpeed;
    this.node.y += this.ySpeed;
  },
  update: function update(dt) {
    this.ballMove();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NlbmVzXFxnYW1lXzAxXFxzY3JpcHRcXG5vcm1hbF9iYWxsLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwieFNwZWVkIiwidHlwZSIsIkZsb2F0IiwieVNwZWVkIiwibWF4TW92ZVNwZWVkIiwibWluTW92ZVNwZWVkIiwib25Mb2FkIiwibWFuYWdlciIsImRpcmVjdG9yIiwiZ2V0Q29sbGlzaW9uTWFuYWdlciIsImVuYWJsZWQiLCJzdGFydCIsImJhbGxNb3ZlIiwiTWF0aCIsImFicyIsIm5vZGUiLCJ4Iiwid2lkdGgiLCJwYXJlbnQiLCJ5IiwiaGVpZ2h0IiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxNQUFNLEVBQUU7QUFDSixpQkFBUyxDQURMO0FBRUpDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZMLEtBREE7QUFNUkMsSUFBQUEsTUFBTSxFQUFFO0FBQ0osaUJBQVMsQ0FETDtBQUVKRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGTCxLQU5BO0FBV1JFLElBQUFBLFlBQVksRUFBRTtBQUNWLGlCQUFTLEVBREM7QUFFVkgsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkMsS0FYTjtBQWdCUkcsSUFBQUEsWUFBWSxFQUFDO0FBQ1QsaUJBQVMsQ0FEQTtBQUVUSixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGQTtBQWhCTCxHQUhQO0FBeUJMO0FBRUFJLEVBQUFBLE1BM0JLLG9CQTJCSztBQUNOLFFBQUlDLE9BQU8sR0FBR1gsRUFBRSxDQUFDWSxRQUFILENBQVlDLG1CQUFaLEVBQWQ7QUFDQUYsSUFBQUEsT0FBTyxDQUFDRyxPQUFSLEdBQWtCLElBQWxCLENBRk0sQ0FHTjtBQUNILEdBL0JJO0FBaUNMQyxFQUFBQSxLQWpDSyxtQkFpQ0ksQ0FFUixDQW5DSTtBQXFDTEMsRUFBQUEsUUFyQ0ssc0JBcUNPO0FBQ1IsUUFBR0MsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS0MsSUFBTCxDQUFVQyxDQUFuQixJQUF3QixLQUFLRCxJQUFMLENBQVVFLEtBQVYsR0FBZ0IsQ0FBeEMsSUFBNkMsS0FBS0YsSUFBTCxDQUFVRyxNQUFWLENBQWlCRCxLQUFqQixHQUF1QixDQUF2RSxFQUEwRTtBQUN0RSxXQUFLakIsTUFBTCxHQUFjLENBQUMsS0FBS0EsTUFBcEI7QUFDSDs7QUFDRCxRQUFHYSxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLQyxJQUFMLENBQVVJLENBQW5CLElBQXdCLEtBQUtKLElBQUwsQ0FBVUssTUFBVixHQUFpQixDQUF6QyxJQUE4QyxLQUFLTCxJQUFMLENBQVVHLE1BQVYsQ0FBaUJFLE1BQWpCLEdBQXdCLENBQXpFLEVBQTRFO0FBQ3hFLFdBQUtqQixNQUFMLEdBQWMsQ0FBQyxLQUFLQSxNQUFwQjtBQUNILEtBTk8sQ0FRUjtBQUNBOzs7QUFFQSxTQUFLWSxJQUFMLENBQVVDLENBQVYsSUFBZSxLQUFLaEIsTUFBcEI7QUFDQSxTQUFLZSxJQUFMLENBQVVJLENBQVYsSUFBZSxLQUFLaEIsTUFBcEI7QUFDSCxHQWxESTtBQW9ETGtCLEVBQUFBLE1BcERLLGtCQW9ER0MsRUFwREgsRUFvRE87QUFDUixTQUFLVixRQUFMO0FBQ0g7QUF0REksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHhTcGVlZDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiAwLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5GbG9hdFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIHlTcGVlZDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiAwLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5GbG9hdFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIG1heE1vdmVTcGVlZDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiAyMCxcclxuICAgICAgICAgICAgdHlwZTogY2MuRmxvYXRcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBtaW5Nb3ZlU3BlZWQ6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiA4LFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5GbG9hdFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICBsZXQgbWFuYWdlciA9IGNjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKTtcclxuICAgICAgICBtYW5hZ2VyLmVuYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgIC8vbWFuYWdlci5lbmFibGVkRGVidWdEcmF3ID0gdHJ1ZTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgYmFsbE1vdmUgKCkge1xyXG4gICAgICAgIGlmKE1hdGguYWJzKHRoaXMubm9kZS54KSArIHRoaXMubm9kZS53aWR0aC8yID49IHRoaXMubm9kZS5wYXJlbnQud2lkdGgvMikge1xyXG4gICAgICAgICAgICB0aGlzLnhTcGVlZCA9IC10aGlzLnhTcGVlZDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYoTWF0aC5hYnModGhpcy5ub2RlLnkpICsgdGhpcy5ub2RlLmhlaWdodC8yID49IHRoaXMubm9kZS5wYXJlbnQuaGVpZ2h0LzIpIHtcclxuICAgICAgICAgICAgdGhpcy55U3BlZWQgPSAtdGhpcy55U3BlZWQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyB0aGlzLnhTcGVlZCA9IHRoaXMuYWNjZWwgKiB0aGlzLnhTcGVlZDtcclxuICAgICAgICAvLyB0aGlzLnlTcGVlZCA9IHRoaXMuYWNjZWwgKiB0aGlzLnlTcGVlZDtcclxuXHJcbiAgICAgICAgdGhpcy5ub2RlLnggKz0gdGhpcy54U3BlZWQ7XHJcbiAgICAgICAgdGhpcy5ub2RlLnkgKz0gdGhpcy55U3BlZWQ7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmJhbGxNb3ZlKCk7XHJcbiAgICB9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------
