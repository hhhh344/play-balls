
require('./assets/prefabs/script/heart');
require('./assets/prefabs/script/trap');
require('./assets/scenes/game_01/script/game');
require('./assets/scenes/game_01/script/normal_ball');
