"use strict";
cc._RF.push(module, 'e34f9ZPS2BFdYRhX8PQ4I8j', 'heart');
// prefabs/script/heart.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    nextSceneName: {
      type: cc.String,
      "default": 'game_01'
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var manager = cc.director.getCollisionManager();
    manager.enabled = true;
  },
  start: function start() {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    console.log('win');
    cc.director.loadScene(this.nextSceneName);
  },
  update: function update(dt) {}
});

cc._RF.pop();