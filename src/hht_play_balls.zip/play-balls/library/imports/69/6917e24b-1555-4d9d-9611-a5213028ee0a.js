"use strict";
cc._RF.push(module, '6917eJLFVVNnZYRpSEwKO4K', 'normal_ball');
// scenes/game_01/script/normal_ball.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    xSpeed: {
      "default": 0,
      type: cc.Float
    },
    ySpeed: {
      "default": 0,
      type: cc.Float
    },
    maxMoveSpeed: {
      "default": 20,
      type: cc.Float
    },
    minMoveSpeed: {
      "default": 8,
      type: cc.Float
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var manager = cc.director.getCollisionManager();
    manager.enabled = true; //manager.enabledDebugDraw = true;
  },
  start: function start() {},
  ballMove: function ballMove() {
    if (Math.abs(this.node.x) + this.node.width / 2 >= this.node.parent.width / 2) {
      this.xSpeed = -this.xSpeed;
    }

    if (Math.abs(this.node.y) + this.node.height / 2 >= this.node.parent.height / 2) {
      this.ySpeed = -this.ySpeed;
    } // this.xSpeed = this.accel * this.xSpeed;
    // this.ySpeed = this.accel * this.ySpeed;


    this.node.x += this.xSpeed;
    this.node.y += this.ySpeed;
  },
  update: function update(dt) {
    this.ballMove();
  }
});

cc._RF.pop();