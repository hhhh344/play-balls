"use strict";
cc._RF.push(module, '6341fEmalJPZKYBNwA2z0ZQ', 'trap');
// prefabs/script/trap.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    nextSceneName: {
      type: cc.String,
      "default": 'game_01'
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var manager = cc.director.getCollisionManager();
    manager.enabled = true; // manager.enabledDebugDraw = true;
  },
  start: function start() {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    console.log('fail');
    cc.director.loadScene(this.nextSceneName);
  } // update (dt) {},

});

cc._RF.pop();