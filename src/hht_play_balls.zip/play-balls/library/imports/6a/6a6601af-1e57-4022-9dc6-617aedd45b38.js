"use strict";
cc._RF.push(module, '6a660GvHldAIp3GYXrt1Fs4', 'game');
// scenes/game_01/script/game.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    player: {
      type: cc.Node,
      "default": null
    },
    border: {
      type: cc.Node,
      "default": null
    },
    rectangle: {
      type: cc.Node,
      "default": null
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var _this = this;

    var player = this.player;
    var playerScript = player.getComponent('normal_ball');
    var maxSpeed = playerScript.maxMoveSpeed;
    var minSpeed = playerScript.minMoveSpeed;
    var border = this.border;
    var rect = this.rectangle;
    var rectHeight = rect.height; //rectangle的高度与原高度之比小于该值，则取消发射小球

    var cancelRatio = 0.2; //鼠标与小球的距离≥maxDistance时，蓄力条满

    var maxDistance = 150; //rectangle的高度与原高度之比

    var ratio = 0; //蓄力条向量

    var vecX = 0,
        vecY = 0,
        vecLength = 0; //设置蓄力条透明，位置在小球上

    border.opacity = 0;
    var _ref = [player.x, player.y];
    border.x = _ref[0];
    border.y = _ref[1];
    this.node.on(cc.Node.EventType.TOUCH_START, function (e) {
      if (playerScript.xSpeed == 0 && playerScript.ySpeed == 0) {
        border.opacity = 255;
        vecX = player.x + _this.node.width / 2 - e.getLocationX();
        vecY = player.y + _this.node.height / 2 - e.getLocationY();
        vecLength = Math.sqrt(Math.pow(vecX, 2) + Math.pow(vecY, 2)); //蓄力条角度控制

        var theta = 360 * Math.atan(vecX / vecY) / (2 * Math.PI);

        if (vecY < 0) {
          theta += 180;
        }

        border.angle = -theta; //蓄力条长度控制

        ratio = vecLength / maxDistance;

        if (ratio <= cancelRatio) {
          rect.height = 0;
        } else if (ratio < 1) {
          rect.height = ratio * rectHeight;
        } else {
          rect.height = rectHeight;
        }
      }
    });
    this.node.on(cc.Node.EventType.TOUCH_MOVE, function (e) {
      if (playerScript.xSpeed == 0 && playerScript.ySpeed == 0) {
        vecX = player.x + _this.node.width / 2 - e.getLocationX();
        vecY = player.y + _this.node.height / 2 - e.getLocationY();
        vecLength = Math.sqrt(Math.pow(vecX, 2) + Math.pow(vecY, 2)); //蓄力条角度控制

        var theta = 360 * Math.atan(vecX / vecY) / (2 * Math.PI);

        if (vecY < 0) {
          theta += 180;
        }

        border.angle = -theta; //蓄力条长度控制

        ratio = vecLength / maxDistance;

        if (ratio <= cancelRatio) {
          rect.height = 0;
        } else if (ratio < 1) {
          rect.height = ratio * rectHeight;
        } else {
          rect.height = rectHeight;
        }
      }
    });
    this.node.on(cc.Node.EventType.TOUCH_END, function (e) {
      if (playerScript.xSpeed == 0 && playerScript.ySpeed == 0) {
        border.opacity = 0;
        var deltaSpeed = maxSpeed - minSpeed;
        var cosTheta = vecX / vecLength;
        var sinTheta = vecY / vecLength;
        var speed = ratio * deltaSpeed + minSpeed;

        if (ratio > cancelRatio) {
          var _ref2 = [cosTheta * speed, sinTheta * speed];
          playerScript.xSpeed = _ref2[0];
          playerScript.ySpeed = _ref2[1];
        }
      }
    });
  },
  start: function start() {},
  update: function update(dt) {// if(this.canLaunch === true) {
    //     const playerScript = this.player.getComponent('normal_ball');
    //     [playerScript.xSpeed, playerScript.ySpeed] = 
    //     [this.cosTheta * this.speed, this.sinTheta * this.speed];
    //     this.canLaunch = false;
    // }
  }
});

cc._RF.pop();